package com.pojo;

public class StudentQueryVo {
   private Student stu;

   
   
   
   
   
   
   
   
   
public Student getStu() {
	return stu;
}

public void setStu(Student stu) {
	this.stu = stu;
}

   
   
   
   
   
   
   
   
   
   
}
